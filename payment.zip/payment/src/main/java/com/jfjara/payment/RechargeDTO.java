package com.jfjara.payment;

import io.micronaut.serde.annotation.Serdeable;

@Serdeable
public record RechargeDTO(String userId, Double amount) {
}
