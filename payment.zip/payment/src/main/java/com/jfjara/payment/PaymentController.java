package com.jfjara.payment;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;

import java.util.HashMap;
import java.util.Map;

@Controller
public class PaymentController {

    Map<String, Double> balance = new HashMap<>();

    public PaymentController() {
        balance.put("jjb", 30.0);
        balance.put("other", 200.0);
    }

    @Post("/recharge")
    public HttpResponse<String> recharge(final @Body RechargeDTO rechargeDTO) {
        if (rechargeDTO.amount() == null || rechargeDTO.amount() <= 0) {
            return HttpResponse.badRequest("Cantidad inválida");
        }

        balance.merge(rechargeDTO.userId(), rechargeDTO.amount(), Double::sum);

        return HttpResponse.ok(
                String.format("Updated balance: %s", balance.get(rechargeDTO.userId()))
        );
    }

    @Post("/refund")
    public HttpResponse<String> refund(final @Body PaymentRequestDTO payment) {
        if (payment.price() == null || payment.price() <= 0) {
            return HttpResponse.badRequest("Cantidad inválida");
        }

        balance.merge(payment.userId(), payment.price(), Double::sum);

        return HttpResponse.ok(
                String.format("Updated balance: %s", balance.get(payment.userId()))
        );
    }

    @Post(uri = "/payment", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
    public HttpResponse<PaymentStatusDTO> payment(final @Body PaymentRequestDTO paymentDTO) {
        if (paymentDTO.price() == null || paymentDTO.price() <= 0) {
            return HttpResponse.badRequest(PaymentStatusDTO.FAILED);
        }

        if (!balance.containsKey(paymentDTO.userId())) {
            return HttpResponse.badRequest(PaymentStatusDTO.FAILED);
        }

        double currentBalance = balance.get(paymentDTO.userId());
        if (currentBalance < paymentDTO.price()) {
            return HttpResponse.ok(PaymentStatusDTO.WITHOUT_BALANCE);
        }

        balance.computeIfPresent(paymentDTO.userId(), (userId, oldBalance) -> oldBalance - paymentDTO.price());
        return HttpResponse.ok(PaymentStatusDTO.OK);
    }


}
