package com.jfjara.payment;

import io.micronaut.serde.annotation.Serdeable;

@Serdeable
public record PaymentRequestDTO(String userId, Double price) {
}
