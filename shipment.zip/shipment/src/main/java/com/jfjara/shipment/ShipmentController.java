package com.jfjara.shipment;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;

import java.util.HashMap;
import java.util.Map;

@Controller
public class ShipmentController {

    Map<String, Integer> products = new HashMap<>();

    public ShipmentController() {
        products.put("1", 3);
        products.put("2", 5);
    }

    @Post(uri = "/ship", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
    public HttpResponse<ShipmentStatusDTO> payment(final @Body ShipmentRequestDTO shipmentRequestDTO) {

        if (!products.containsKey(shipmentRequestDTO.productId())) {
            return HttpResponse.badRequest(ShipmentStatusDTO.FAILED);
        }

        int totalAvailable = products.get(shipmentRequestDTO.productId());
        if (totalAvailable <= 0) {
            return HttpResponse.ok(ShipmentStatusDTO.OUT_OF_STOCK);
        }

        products.computeIfPresent(shipmentRequestDTO.productId(), (productId, oldTotal) -> oldTotal - 1);
        return HttpResponse.ok(ShipmentStatusDTO.OK);
    }


}
