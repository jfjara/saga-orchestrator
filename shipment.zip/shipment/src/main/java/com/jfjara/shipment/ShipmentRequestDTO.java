package com.jfjara.shipment;

import io.micronaut.serde.annotation.Serdeable;

@Serdeable
public record ShipmentRequestDTO(String productId) {
}
