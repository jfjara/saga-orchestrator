package com.jfjara.shipment;

import io.micronaut.serde.annotation.Serdeable;

@Serdeable
public enum ShipmentStatusDTO {
    OK, OUT_OF_STOCK, FAILED
}
